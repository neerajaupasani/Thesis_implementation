# import statements

import numpy as np
from sklearn.metrics import f1_score, accuracy_score
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import MultiLabelBinarizer
import pandas as pd
import networkx as nx



class TopKRanker(OneVsRestClassifier):
    def predict(self, X, top_k_list):
        probs = np.asarray(super(TopKRanker, self).predict_proba(X))
        all_labels = []
        for i, k in enumerate(top_k_list):
            probs_ = probs[i, :]
            labels = self.classes_[probs_.argsort()[-k:]].tolist()
            probs_[:] = 0
            probs_[labels] = 1
            all_labels.append(probs_)
        return np.asarray(all_labels)


class Cora_classify():


    def __init__(self, embeddings,clf):
        self.embeddings = embeddings
        self.clf = TopKRanker(clf)
        self.binarizer = MultiLabelBinarizer(sparse_output=True)
        #self.name = name
        #self.emb = embeddings




    def train(self, X, Y, Y_all):
        self.binarizer.fit(Y_all)
        X_train = [self.embeddings[x] for x in X]
        Y = self.binarizer.transform(Y)
        self.clf.fit(X_train, Y)

    def evaluate(self, X, Y):
        top_k_list = [len(l) for l in Y]
        Y_ = self.predict(X, top_k_list)
        Y = self.binarizer.transform(Y)

        averages = ["micro", "macro", "samples", "weighted"]
        results = {}
        for average in averages:
            results[average] = f1_score(Y, Y_, average=average)

        results['acc'] = accuracy_score(Y, Y_)
        print('-------------------')
        print(results)
        return results

    def predict(self, X, top_k_list):
        X_ = np.asarray([self.embeddings[x] for x in X])
        Y = self.clf.predict(X_, top_k_list=top_k_list)
        return Y

    def split_train_evaluate(self, X, Y, train_precent,seed=0):
        state = np.random.get_state()

        training_size = int(train_precent * len(X))
        np.random.seed(seed)
        shuffle_indices = np.random.permutation(np.arange(len(X)))
        X_train = [X[shuffle_indices[i]] for i in range(training_size)]
        Y_train = [Y[shuffle_indices[i]] for i in range(training_size)]
        X_test = [X[shuffle_indices[i]] for i in range(training_size, len(X))]
        Y_test = [Y[shuffle_indices[i]] for i in range(training_size, len(X))]

        self.train(X_train, Y_train, Y)
        np.random.set_state(state)
        return self.evaluate(X_test, Y_test)

graph = "cora-edgelist.txt"
type_of_graph = nx.Graph()

# to read from the file

new_graph = nx.read_edgelist(graph, create_using=type_of_graph, nodetype=int)


# Load Embeddings and labels

model = pd.read_csv("cora_cembed.csv", header=None)
model1 = pd.read_csv("cora_jembed.csv", header=None)
model2 = pd.read_csv("cora_lembed.csv", header=None)
model3 = pd.read_csv("cora_pembed.csv", header=None)
#new = model[0].str.split(' ', expand=True)
model_arr = model.values
model_arr1 = model1.values
model_arr2 = model2.values
model_arr3 = model3.values
#print(model_arr)



#embeddings = model.to_dict('index')

#model_arr = list(embeddings.values())



#print(type(embeddings.values()))

#cosine embeddings

global embeddings

embeddings = {}

for i in range(len(new_graph.nodes())):

    embeddings[i] = model_arr[i]

#jaccard embeddings

global embeddings1

embeddings1 = {}

for i in range(len(new_graph.nodes())):
    embeddings1[i] = model_arr1[i]

#lhn1 embeddings

global embeddings2

embeddings2 = {}

for i in range(len(new_graph.nodes())):
    embeddings2[i] = model_arr2[i]

#pmi embeddings

global embeddings3

embeddings3 = {}

for i in range(len(new_graph.nodes())):
    embeddings3[i] = model_arr3[i]


#embeddings = {key: int(value) for key,value in embeddings.items()}

#print(embeddings.keys())





#embeddings = {str(key): value for key,value in embeddings.items()}

#embedd_arr = embeddings.values()

#print(embedd_arr)
#print(new)

#print(embeddings)



def read_cora_node_label(filename=None,embeddings=None):
    #global embeddings
    fin = open(filename, 'r')
    X = []
    Y = []

    label = {}

    for line in fin:
        a = line.strip('\n').split(' ')
        label[a[0]] = a[1]

    #     while 1:
    #         if skip_head:
    #             fin.readline()
    #         l = fin.readline()
    #         if l == '':
    #             break
    #         vec = l.strip().split(' ')
    #        #Y.append(vec[1:])

    fin.close()
    for i in embeddings:
        X.append(i)
        Y.append(label[str(i)])


    #print(X)
    #print(Y)
    return X, Y





#eval = Classifier(embedd_arr, OneVsRestClassifier)





#print(embeddings)

#model_dict = model.to_dict()
#print(type(model_dict))

#embeddings = embedd_data.values

#embed = embeddings.ravel()

#X_ = []

#for index, val in np.ndenumerate(embeddings):

    #indx = index[0]

    #X_.append(indx)

#emb = np.array(X_)


    #print(X)

#label_df = pd.read_table('cora-label.txt', delim_whitespace=True, names=('node_id', 'labels'))
#Y = label_df['labels'].values



















