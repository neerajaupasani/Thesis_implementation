#import statements

#from link_pred import Link_Prediction
from cora_lp import Cora_linkprediction
#from classify import read_node_label, Classifier
import cite_classification
from cite_classification import embeddings, embeddings1, embeddings2 , embeddings3
import cite_lp
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from cora_lp import Cora_linkprediction
#from att_infer import LogRegressor
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
#from regression import Regressor
import numpy as np
import warnings




class Eval:
    def cosine_classification(self,embeddings, label_path, name):

        X, Y = cite_classification.read_cite_node_label(label_path,embeddings)

        f_c=open('cite_nc_cos.txt', 'w+')

        for tr_frac in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:

               print("Training classifier using {:.2f}% nodes...".format(tr_frac * 100))
               clf = cite_classification.Cite_classify(embeddings=embeddings,clf=LogisticRegression())
               results= clf.split_train_evaluate(X, Y, tr_frac)
               warnings.filterwarnings('ignore')

               for avg in [ "macro"]:
                 f_c.write(name + ' '+ str(tr_frac)+ ' '+avg+ ' '+ str('%0.5f'%results[avg]))
                 f_c.write('\n')

    def jaccard_classification(self,embeddings, label_path, name):

        X, Y = cite_classification.read_cite_node_label(label_path,embeddings)

        f_c=open('cite_nc_jac.txt', 'w+')

        for tr_frac in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:

               print("Training classifier using {:.2f}% nodes...".format(tr_frac * 100))
               clf = cite_classification.Cite_classify(embeddings=embeddings,clf=LogisticRegression())
               results= clf.split_train_evaluate(X, Y, tr_frac)
               warnings.filterwarnings('ignore')

               for avg in [ "macro"]:
                 f_c.write(name + ' '+ str(tr_frac)+ ' '+avg+ ' '+ str('%0.5f'%results[avg]))
                 f_c.write('\n')

    def lhn1_classification(self,embeddings, label_path, name):

        X, Y = cite_classification.read_cite_node_label(label_path,embeddings)

        f_c=open('cite_nc_lhn1.txt', 'w+')

        for tr_frac in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:

               print("Training classifier using {:.2f}% nodes...".format(tr_frac * 100))
               clf = cite_classification.Cite_classify(embeddings=embeddings,clf=LogisticRegression())
               results= clf.split_train_evaluate(X, Y, tr_frac)
               warnings.filterwarnings('ignore')

               for avg in [ "macro"]:
                 f_c.write(name + ' '+ str(tr_frac)+ ' '+avg+ ' '+ str('%0.5f'%results[avg]))
                 f_c.write('\n')

    def pmi_classification(self,embeddings, label_path, name):

        X, Y = cite_classification.read_cite_node_label(label_path,embeddings)

        f_c=open('cite_nc_pmi.txt', 'w+')

        for tr_frac in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:

               print("Training classifier using {:.2f}% nodes...".format(tr_frac * 100))
               clf = cite_classification.Cite_classify(embeddings=embeddings,clf=LogisticRegression())
               results= clf.split_train_evaluate(X, Y, tr_frac)
               warnings.filterwarnings('ignore')

               for avg in [ "macro"]:
                 f_c.write(name + ' '+ str(tr_frac)+ ' '+avg+ ' '+ str('%0.5f'%results[avg]))
                 f_c.write('\n')



    def link_prediction_cosine(self, edge_file, embeddings, size, name):

            clf = cite_lp.Cite_linkprediction(embeddings=embeddings, edge_file= edge_file)
            auc=clf.predict(size)

            functions = ["hadamard","average","l1","l2"]

            f_l = open('cite_lp_cosine_%d.txt' % size, 'w+')

            for i in functions:
                print(i, '%.3f' % np.mean(auc[i]))

                f_l.write(name + ' ' + str(size) + ' ' + str(i) + ' ' + str('%.3f' % np.mean(auc[i])))
                f_l.write('\n')

    def link_prediction_jaccard(self, edge_file, embeddings, size, name):

            clf = cite_lp.Cite_linkprediction(embeddings=embeddings, edge_file= edge_file)
            auc=clf.predict(size)

            functions = ["hadamard","average","l1","l2"]

            f_l = open('cite_lp_jaccard_%d.txt' % size, 'w+')

            for i in functions:
                print(i, '%.3f' % np.mean(auc[i]))

                f_l.write(name + ' ' + str(size) + ' ' + str(i) + ' ' + str('%.3f' % np.mean(auc[i])))
                f_l.write('\n')

    def link_prediction_lhn1(self, edge_file, embeddings, size, name):

            clf = cite_lp.Cite_linkprediction(embeddings=embeddings, edge_file= edge_file)
            auc=clf.predict(size)

            functions = ["hadamard","average","l1","l2"]

            f_l = open('cite_lp_lhn1_%d.txt' % size, 'w+')

            for i in functions:
                print(i, '%.3f' % np.mean(auc[i]))

                f_l.write(name + ' ' + str(size) + ' ' + str(i) + ' ' + str('%.3f' % np.mean(auc[i])))
                f_l.write('\n')

    def link_prediction_pmi(self, edge_file, embeddings, size, name):

            clf = cite_lp.Cite_linkprediction(embeddings=embeddings, edge_file= edge_file)
            auc=clf.predict(size)

            functions = ["hadamard","average","l1","l2"]

            f_l = open('cite_lp_pmi_%d.txt' % size, 'w+')

            for i in functions:
                print(i, '%.3f' % np.mean(auc[i]))

                f_l.write(name + ' ' + str(size) + ' ' + str(i) + ' ' + str('%.3f' % np.mean(auc[i])))
                f_l.write('\n')





eval = Eval()
eval.cosine_classification(embeddings=embeddings,label_path='citeseer-label.txt',name='cite-cosine')
eval.jaccard_classification(embeddings=embeddings1,label_path='citeseer-label.txt',name='cite-jaccard')
eval.lhn1_classification(embeddings=embeddings2,label_path='citeseer-label.txt',name='cite-lhn1')
eval.pmi_classification(embeddings=embeddings3,label_path='citeseer-label.txt',name='cite-pmi')

eval.link_prediction_cosine('citeseer-edgelist.txt',embeddings=embeddings,size=128,name='cite-cosine')
eval.link_prediction_jaccard('citeseer-edgelist.txt',embeddings=embeddings1,size=128,name='cite-jaccard')
eval.link_prediction_lhn1('citeseer-edgelist.txt',embeddings=embeddings2,size=128,name='cite-lhn1')
eval.link_prediction_pmi('citeseer-edgelist.txt',embeddings=embeddings3,size=128,name='cite-pmi')



    #def __init__(self):
    #     self.edge_file = edge_file
    #     self.adj = adj
    #     self.embeddings = embeddings
    #     self.label_path= label_path
    #     self.name=name


